n = int(input("eded: "))
n = abs(n)
a = n%10
b = n//10%10
c = n//100
print(a+b+c , a*b*c)

#3reqemli ededin cem ve hasilini tapir
