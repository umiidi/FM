import os
import random

datafilename = "students.txt"
Students = []

def main():
    ImportStudents()
    Menu()

# Menu
def Menu():
    print("--------------------------\n"
          "| 1. Random Student      |\n"      
          "| 2. Print All Student   |\n"     
          "| 3. Add Student         |\n"                  
          "| 4. Remove Student      |\n"                    
          "| 5. Exit                |"              
          "\n--------------------------")
    n = InputTest(1,5)
    if n==1:
        os.system('cls')
        RandomStudent()
        Menu()
    elif n==2:
        os.system('cls')
        PrintAllStudent()
        Menu()
    elif n==3:
        os.system('cls')
        AddStudent()
        Menu()
    elif n==4: 
        os.system('cls')
        RemoveStudent()
        Menu()
    elif n==5: exit("Goodbye, friend.")
    else: exit("Error, Please report a bug")

#Random Student
def RandomStudent():
    n = InputTest(1, len(Students),"How many students should be selected? (max %d student): "%len(Students))
    SelectedStudents = random.sample(Students, n)
    for i in SelectedStudents:
        print("%s %s"%(i[0], i[1]))
    else:
        print("\nDo you want to write the selected students to the file?\n"
              "1. YES\n"
              "2. NO")
        n = InputTest(1,2)
        if n==1:
            WriteStudentInFile(SelectedStudents, 'w',input("Please enter a file name: ")+".txt")
            print("Selected students successfully written to file!\n")
        elif n==2: return
        else: exit("Error, Please report a bug")

#Add Student
def AddStudent():
    name = input("Enter name: ")
    surname = input("Enter surname: ")
    Students.append([name, surname])
    WriteStudentInFile([[name,surname]])
    print("Added successfully")

#Remove Student
def RemoveStudent():
    name = input("Enter the name of the student you want to remove: ")
    found, index = SearchName(name)
    if len(found) == 0: 
        print("No student with such a name was found")
        return
    elif(len(found) == 1): Remove(index[0])
    else:
        for i in range(len(found)):
            print("%d."%(i+1),found[i][0], found[i][1])
        else:
            x = InputTest(1, len(found), "Enter the index: ")
            Remove(index[x-1])
    print("Removed successfully")

def Remove(index):
    Students.pop(index)
    WriteStudentInFile(Students, 'w')

# SearchProcess
def SearchName(name):
    found = []
    index = []
    for i in range(len(Students)):
        if Students[i][0].lower() == name.lower():
            found.append(Students[i])
            index.append(i)
    else: return found, index

#Print All Student
def PrintAllStudent():
    for i in range(len(Students)):
     print("%d: %s %s"%(i+1, Students[i][0], Students[i][1]))
    else: return

#Input Test
def InputTest(a,b, message = "Please, select menu: "):
    for i in range(4):
        if i == 0:
            n = input(message).strip()
            if NumberIntervalTest(n,a,b): return int(n)
        elif i != 3:
            n = input("Incorrect, Please re-enter: ").strip()
            if NumberIntervalTest(n,a,b): return int(n)
        else:
            n = input("Final warning!, re-enter: ").strip()
            if NumberIntervalTest(n,a,b): return int(n)
    else: exit("You have checked too many times")

def NumberIntervalTest(n,a,b):
    return n.isnumeric() and (int(n) in range(a,b+1))

# Read, Write and Remove
def ImportStudents():
    lines = ReadFile(datafilename)
    for i in lines:
        if i == "\n": continue
        line = i.split()
        name = line[0]
        surname = line[1]
        Students.append([name,surname])

def ReadFile(filename):
    try:
        with open(filename, 'r') as f:
            return f.readlines()
    except:
        exit("No Read File")

def WriteStudentInFile(list, parametr = 'a',filename = datafilename):
    lines = ""
    for i in list:
        lines+="%s %s\n"%(i[0], i[1])
    else: WriteFile(filename, lines, parametr)

def WriteFile(filename, lines, parametr = 'a'):
    with open(filename, parametr) as f:
        f.writelines(lines)

def RemoveFromFile():
    pass

if __name__ == "__main__":
    main()
