import random
import math
def main():
    lines = read_from_file()
    number_of_questions = len(lines)
    number_of_tickets = int(input("Number of tickets: "))
    tickets =  process(number_of_questions, number_of_tickets)
    write_tickets_to_file(tickets, lines)
    
#Setting the questions on the ticket
def process(numbers, tickets):
    interval = numbers//5
    limit = math.ceil(tickets/interval)
    a = 1
    b = interval
    questions_numbers = []
    for i in range(5):
        questions_number = []
        while len(questions_number) != tickets:
            number = random.randint(a, b)
            if questions_number.count(number) < limit:
                questions_number.append(number)
        else: questions_numbers.append(questions_number)
        a = b
        b = a+interval
    else: 
        return questions_numbers
    
#Writing questions to file
def write_tickets_to_file(tickets, lines):
    for i in range(len(tickets[0])):
        write_to_file(str(i+1) + ". ticket\n")
        oneticket = ""
        for j in range(5):
            oneticket += lines[tickets[j][i]-1]
        else:
            write_to_file(oneticket)
        write_to_file("\n\n")
    else: write_to_file("---------------------------------------------------------\n\n")

#Write text to file
def write_to_file(text):
    with open("tickets.txt", "a") as f:
        f.writelines(text)

#Reading the questions from the file
def read_from_file():
    try:
        with open("questions.txt", 'r') as f:
            return f.readlines()
    except: print("No read file")


if __name__ == "__main__":
    main()