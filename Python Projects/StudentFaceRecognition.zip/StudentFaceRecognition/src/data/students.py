class Student:
    def __init__(self, id, name, surname, img):
        self.id = int(id)
        self.name = name
        self.surname = surname
        self.img = img
