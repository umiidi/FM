from src.Starter.start import StartApp
StartApp()

# @author Umid