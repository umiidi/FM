from src.Quiz.quizutil import OneQuizGenerator, PrintInputQuiz, Calculator
from time import sleep

def StartQuiz(user):
    print("\nThe exam has started. Good luck, friend!")
    sleep(0.5)
    QuizGenerator(user)

def QuizGenerator(user):
    incorrectanswers = []
    cs=0 ; ins=0

    for i in range(10):
        quiz = OneQuizGenerator(user.level)
        a = int(quiz[0])
        b = int(quiz[1])
        o = quiz[2]
        result = PrintInputQuiz(a, b, o)
        correctresult = Calculator(a,b,o)
        if result == correctresult:
            cs+=1
        else:
            ins+=1
            inc = [str(a), str(b), o, str(result), str(correctresult)]
            incorrectanswers.append(inc)
    else: PrinterFinal(user, cs, ins, incorrectanswers)

def PrinterFinal(user, cs, ins, incorrectanswers):
    newscore = cs - ins//4
    user.AddScore(newscore)
    if ins==0:
        user.AddLevel()
        sleep(0.5)
        print("Congrats friend, You passed to level " + str(user.GetLevel()) + "\n")
    else:
        sleep(0.5)
        print("\nIncorrect Answers:")
        PrinterIncorrectAnswer(incorrectanswers)
    sleep(1)
    print("Result:")
    print("Correct answers: " + str(cs))
    print("Incorrect answers: " + str(ins))
    print("Your score now: " + str(newscore))
    print("Total score: " + str(user.GetScore()))

def PrinterIncorrectAnswer(incorrectanswers):
    for inc in incorrectanswers:
        sleep(0.5)
        print(inc[0] + inc[2] + inc[1]  + "= ?")
        print("Your Answer: " + str(inc[3]))
        print("Correct Answer: " + str(inc[4]))
        print("\n",end='')
        sleep(0.1)
